import { useState } from "react";


function Calculator() {
  const [num1, setNum1] = useState("");
  const [num2, setNum2] = useState("");
  const [operation, setOperation] = useState("+");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const calculateResult = () => {
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);
    
    if (isNaN(number1) || isNaN(number2)) {
      setError("Грешка: Моля, въведете валидни числа.");
      setResult(null);
      return;
    }
    
    let res;
    switch (operation) {
      case "+":
        res = number1 + number2;
        break;
      case "-":
        res = number1 - number2;
        break;
      case "*":
        res = number1 * number2;
        break;
      case "/":
        if (number2 === 0) {
          setError("Грешка: деление на 0 е невъзможно!");
          setResult(null);
          return;
        }
        res = number1 / number2;
        break;
      default:
        res = "Невалидна операция";
    }
    setError("");
    setResult(res);
  };

  return (
    <div className="calculator">
      <InputComponent
        num1={num1}
        num2={num2}
        setNum1={setNum1}
        setNum2={setNum2}
        operation={operation}
        setOperation={setOperation}
        calculateResult={calculateResult}
      />
      <ResultComponent result={result} error={error} />
    </div>
  );
}

function InputComponent({ num1, num2, setNum1, setNum2, operation, setOperation, calculateResult }) {
  return (
    <div>
      <input type="number" value={num1} onChange={(e) => setNum1(e.target.value)} placeholder="Число 1" />
      <select value={operation} onChange={(e) => setOperation(e.target.value)}>
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
      </select>
      <input type="number" value={num2} onChange={(e) => setNum2(e.target.value)} placeholder="Число 2" />
      <button onClick={calculateResult}>Изчисли</button>
    </div>
  );
}

function ResultComponent({ result, error }) {
  return (
    <div>
      {error ? <p style={{ color: "red" }}>{error}</p> : <p>Резултат: {result}</p>}
    </div>
  );
}

export default Calculator;
